# gallery-starter
This is starter code for assignment seven of Intermediate Web Design
